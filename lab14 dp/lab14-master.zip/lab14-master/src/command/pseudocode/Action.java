package command.pseudocode;

public interface Action {
    void perform();
}
