package command.demoprogram;

public interface Command {
    void execute();
}
