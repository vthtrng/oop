package bridge.demoprogram;

public interface OperatingSystem {
    void startUp();
    void loadUrl(String url);
}
