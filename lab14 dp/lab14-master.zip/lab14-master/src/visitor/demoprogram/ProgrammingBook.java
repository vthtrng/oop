package visitor.demoprogram;

public interface ProgrammingBook extends Book {
    String getResource();
}
