package visitor.demoprogram;

public interface Book {
    void accept(Visitor v);
}
