package com.patterns.command.realworld;

public interface Command {
    void execute();
}
