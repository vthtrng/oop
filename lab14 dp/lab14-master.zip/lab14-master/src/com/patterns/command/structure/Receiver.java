package com.patterns.command.structure;

public class Receiver {
    public void action() {
        System.out.println("Called Receiver action()");
    }
}
