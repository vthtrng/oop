package com.patterns.bridge;

public abstract class Implementation {
    public abstract void operation();
}
