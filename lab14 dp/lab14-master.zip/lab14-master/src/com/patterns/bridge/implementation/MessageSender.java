package com.patterns.bridge.implementation;

public interface MessageSender {
    void sendMessage();
}
