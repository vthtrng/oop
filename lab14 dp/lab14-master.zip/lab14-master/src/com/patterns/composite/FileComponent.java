package com.patterns.composite;

public interface FileComponent {
    void showProperty();

    long totalSize();
}
